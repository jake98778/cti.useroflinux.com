import re
import json
import feedparser
from newspaper import Article, ArticleException
from flask import Flask, render_template, jsonify, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
import requests
from datetime import datetime
import os
import threading
import time
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cve.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

app.jinja_env.filters['from_json'] = json.loads

progress = {'total': 0, 'completed': 0, 'done': False}

class CVE(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cve_id = db.Column(db.String(13), unique=True, nullable=False)
    description = db.Column(db.String, nullable=True)
    severity = db.Column(db.Float, nullable=True)
    publication_date = db.Column(db.Date, nullable=True)
    news_articles = db.Column(db.String, nullable=True)

class Keyword(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    word = db.Column(db.String(50), unique=True, nullable=False)

def collect_cves():
    global progress
    rss_feeds = [
        "https://krebsonsecurity.com/feed/",
        "https://feeds.feedburner.com/eset/blog",
        "https://feeds.feedburner.com/TheHackersNews",
        "https://www.bleepingcomputer.com/feed/",
        "https://feeds.securityweek.com/securityweek",
        "https://www.csoonline.com/feed",
        "https://www.cisa.gov/uscert/ncas/alerts.xml"
    ]
    cve_pattern = re.compile(r"CVE-\d{4}-\d{4,7}", re.IGNORECASE)
    API_ENDPOINT = "https://cveawg.mitre.org/api/cve/{}"

    with app.app_context():
        total_articles = 0
        for feed_url in rss_feeds:
            feed = feedparser.parse(feed_url)
            if feed.entries:
                total_articles += min(len(feed.entries), 5)
        total_articles += 1
        progress['total'] = total_articles
        progress['completed'] = 0
        progress['done'] = False
        print(f"Total articles to process: {total_articles}")

        for feed_url in rss_feeds:
            feed = feedparser.parse(feed_url)
            print(f"Processing feed: {feed_url}, {len(feed.entries)} entries")
            feed.entries.append(feedparser.FeedParserDict({
                'link': 'https://test.com',
                'summary': 'Test with CVE-2023-42793 and CVE-2023-1234',
                'title': 'Test Entry'
            }))
            for entry in feed.entries[:5]:
                if not hasattr(entry, 'link') or not entry.link:
                    print(f"Skipping malformed entry: {entry}")
                    progress['completed'] += 1
                    continue
                summary = entry.get('summary', '') or entry.get('description', '')
                print(f"Summary for {entry.link}: {summary[:100]}...")
                cves = set(cve_pattern.findall(summary))
                print(f"Raw CVE matches in summary: {cves}")
                cves = {cve.upper() for cve in cves}
                print(f"Article {entry.link}: Found {len(cves)} CVEs - {cves}")

                for cve_id in cves:
                    existing_cve = CVE.query.filter_by(cve_id=cve_id).first()
                    if existing_cve:
                        articles = json.loads(existing_cve.news_articles or '[]')
                        if entry.link not in articles:
                            articles.append(entry.link)
                            existing_cve.news_articles = json.dumps(articles)
                            try:
                                db.session.commit()
                                print(f"Updated and committed existing CVE: {cve_id}")
                            except Exception as e:
                                print(f"Commit failed for existing {cve_id}: {e}")
                                db.session.rollback()
                    else:
                        try:
                            response = requests.get(API_ENDPOINT.format(cve_id), timeout=10)
                            time.sleep(1)
                            print(f"API response for {cve_id}: {response.status_code}, {response.json() if response.status_code == 200 else response.text[:100]}")
                            if response.status_code == 200:
                                data = response.json()
                                pub_date_str = data.get('cveMetadata', {}).get('datePublished')
                                pub_date = datetime.strptime(pub_date_str, '%Y-%m-%dT%H:%M:%S.%fZ').date() if pub_date_str else datetime.today().date()
                                containers = data.get('containers', {}).get('cna', {})
                                description_data = containers.get('descriptions', [{}])[0]
                                description = description_data.get('value', 'No description available')
                                metrics = containers.get('metrics', [])
                                severity = None
                                if metrics and 'cvssV3_1' in metrics[0]:
                                    severity = metrics[0]['cvssV3_1'].get('baseScore')
                                elif metrics and 'cvssV3_0' in metrics[0]:
                                    severity = metrics[0]['cvssV3_0'].get('baseScore')
                            else:
                                description = f"Awaiting full analysis (HTTP {response.status_code})"
                                severity = None
                                pub_date = datetime.today().date()

                            new_cve = CVE(
                                cve_id=cve_id,
                                description=description,
                                severity=float(severity) if severity else None,
                                publication_date=pub_date,
                                news_articles=json.dumps([entry.link])
                            )
                            db.session.add(new_cve)
                            print(f"Added CVE: {cve_id} to session")
                            db.session.commit()
                            print(f"Committed CVE: {cve_id} to database")
                        except Exception as e:
                            print(f"Commit or API fetch failed for {cve_id}: {e}")
                            db.session.rollback()
                progress['completed'] += 1
                print(f"Progress updated: {progress['completed']}/{progress['total']}")
        progress['done'] = True
        print("Collection complete")

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/cve-list')
def cve_list():
    cves = CVE.query.order_by(CVE.publication_date.desc(), CVE.severity.desc()).all()
    keywords = [kw.word.lower() for kw in Keyword.query.all()]
    print(f"CVE list fetched {len(cves)} CVEs from database, Keywords: {keywords}")
    
    # Preprocess CVE descriptions for highlighting
    highlighted_cves = []
    for cve in cves:
        desc = cve.description if cve.description else ''
        should_highlight = False
        for keyword in keywords:
            if keyword in desc.lower():
                should_highlight = True
                # Case-insensitive replace for all variants
                desc = re.sub(
                    re.escape(keyword),
                    f'<span class="keyword-match">{keyword}</span>',
                    desc,
                    flags=re.IGNORECASE
                )
        highlighted_cves.append({
            'cve_id': cve.cve_id,
            'description': desc,
            'severity': cve.severity,
            'publication_date': cve.publication_date,
            'news_articles': cve.news_articles,
            'should_highlight': should_highlight
        })
    return render_template('index.html', cves=highlighted_cves, keywords=keywords)

@app.route('/update')
def update():
    thread = threading.Thread(target=collect_cves)
    thread.start()
    return render_template('update.html')

@app.route('/progress')
def get_progress():
    global progress
    percentage = (progress['completed'] / progress['total'] * 100) if progress['total'] > 0 else 0
    return jsonify({'percentage': percentage, 'done': progress['done']})

@app.route('/wipe-db', methods=['POST'])
def wipe_db():
    with app.app_context():
        try:
            db.drop_all()
            db.create_all()
            print("Database wiped and recreated")
        except Exception as e:
            print(f"Failed to wipe database: {e}")
            return "Error wiping database", 500
    return redirect(url_for('cve_list'))

@app.route('/keywords', methods=['GET', 'POST'])
def keywords():
    if request.method == 'POST':
        if 'keyword' in request.form:
            keyword = request.form.get('keyword')
            if keyword:
                with app.app_context():
                    existing = Keyword.query.filter_by(word=keyword.lower()).first()
                    if not existing:
                        new_keyword = Keyword(word=keyword.lower())
                        db.session.add(new_keyword)
                        db.session.commit()
                        print(f"Added keyword: {keyword}")
        elif 'delete_id' in request.form:
            delete_id = request.form.get('delete_id')
            with app.app_context():
                keyword = Keyword.query.get(delete_id)
                if keyword:
                    db.session.delete(keyword)
                    db.session.commit()
                    print(f"Deleted keyword: {keyword.word}")
        return redirect(url_for('keywords'))
    keywords = Keyword.query.all()
    return render_template('keywords.html', keywords=keywords)

def schedule_daily_update():
    scheduler = BackgroundScheduler()
    trigger = CronTrigger(hour=5, minute=0)
    scheduler.add_job(collect_cves, trigger)
    scheduler.start()
    print("Scheduled daily CVE update at 5 AM")

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    schedule_daily_update()
    app.run(host='0.0.0.0', port=5000, debug=True)